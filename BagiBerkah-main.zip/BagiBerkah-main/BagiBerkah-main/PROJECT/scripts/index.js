const express = require('express');
const mysql = require('mysql');
const path = require('path');

const app = express();

// Konfigurasi koneksi database
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'nama_database'
});

db.connect((err) => {
  if (err) {
    throw err;
  }
  console.log('MySQL Connected...');
});

// Middleware untuk melayani file statis
app.use(express.static(path.join(__dirname, 'public')));

// Endpoint untuk mendapatkan data dari database
app.get('/api/data', (req, res) => {
  const sql = 'SELECT * FROM nama_tabel';
  db.query(sql, (err, result) => {
    if (err) throw err;
    res.json(result);
  });
});

// Menjalankan server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
